=== Restatify Multi Chat Overlay ===
Contributors: restatify
Tags: chat, support, whatsapp, telegram, messenger, ai
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.4.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Schwebendes Multi-Channel-Chat-Overlay mit integriertem Website-Chat, Support-Posteingang, E-Mail-Benachrichtigungen und optionalen KI-Autoantworten.

== Description ==

Restatify Multi Chat Overlay fuegt im Frontend einen schwebenden Chat-Button hinzu und ermoeglicht:

* Beliebte Messaging-Kanaele anzeigen (WhatsApp, Telegram, Messenger, Discord, Signal, Viber, Threema, WeChat).
* Einen nativen Website-Chat direkt im Overlay aktivieren.
* Jede neue Besuchernachricht an eine konfigurierbare Support-E-Mail senden.
* Einen direkten Admin-Link in Support-E-Mails einbetten, um die passende Unterhaltung zu oeffnen.
* Aus dem WordPress-Admin-Support-Posteingang antworten.
* Optional KI-basierte First-Level-Antworten erzeugen.
* Optional das Booking Assistant Overlay aus dem Support-Posteingang ausloesen.
* Buchungs-Lifecycle-Ereignisse (bestaetigt/abgebrochen) in Support-Unterhaltungen anzeigen.

Dieses Plugin ist fuer kleine Support-Teams gedacht, die E-Mails ueberwachen und einen schnellen Uebergang vom Postfach in aktive Chats brauchen.

== Installation ==

1. Plugin-Ordner nach /wp-content/plugins/ hochladen.
2. Restatify Multi Chat Overlay unter Plugins aktivieren.
3. Zu Einstellungen -> Multi Chat Overlay gehen.
4. Overlay aktivieren.
5. Mindestens eine Kanal-URL konfigurieren oder den integrierten Website-Chat aktivieren.
6. Support-E-Mail-Adresse hinterlegen.
7. Aenderungen speichern.

Fuer externe Installationen kann auch ein Release-ZIP verwendet werden.

ZIP-Paket im Plugin-Workspace erstellen mit:

1. pwsh -NoProfile -ExecutionPolicy Bypass -File ./scripts/create-release-zip.ps1

Das ZIP wird unter /release erstellt.

Wenn "Require cookie consent" aktiviert ist und deine Seite ein eigenes Theme oder eigenes CMP nutzt, hinterlege passende Cookie-Regeln in der Plugin-Einstellung "Consent cookie rules".
Format: cookie_name or cookie_name=expected_value.
Example: restatify_cookie_consent=accepted,cookiesDirective,_cky-consent=accept

== Frequently Asked Questions ==

= Wie aktiviere ich den integrierten Website-Chat? =

Gehe zu Einstellungen -> Multi Chat Overlay und aktiviere "Enable built-in website chat".

= Wo erscheinen eingehende Chat-Nachrichten? =

Im eigenen Admin-Menuepunkt Support Chat.
Dort kannst du Unterhaltungen oeffnen und Support-Antworten senden.

= Versendet das Plugin E-Mail-Benachrichtigungen? =

Ja. Wenn "Send email on new message" aktiviert ist und eine gueltige Support-E-Mail konfiguriert wurde, versendet das Plugin fuer jede neue Besuchernachricht eine Benachrichtigung.

= Ist KI erforderlich? =

Nein. KI-Autoantwort ist optional und standardmaessig deaktiviert.

= Welche KI-Anbieter werden unterstuetzt? =

Das Plugin unterstuetzt diese Anbieter per Endpunkt-Autoerkennung:

* OpenAI (ChatGPT)
* Google Gemini
* Mistral
* DeepSeek
* Llama (including Ollama-style endpoints)

Der API-Endpunkt ist in den Plugin-Einstellungen konfigurierbar.
Der Anbieter wird ueber die konfigurierte Endpunkt-URL erkannt und Request-/Response-Payloads werden automatisch angepasst.

= Unterstuetzt das Plugin Polylang? =

Ja.

Wenn Polylang aktiv ist, registriert das Plugin konfigurierbare Chat-Texte in der Uebersetzungsgruppe "Restatify Multi Chat Overlay".
Diese Texte koennen unter Languages -> Translations uebersetzt werden.

Uebersetzbare Felder:

* Team title
* Intro message
* Channel heading
* Button accessibility label
* Chat title
* Chat input placeholder
* Send button label
* AI system prompt

= Benoetigt dieses Plugin den Booking Assistant? =

Nein. Die Booking-Assistant-Integration ist optional.

Wenn Booking Assistant installiert ist, kann der Support das Oeffnen des Booking-Overlays beim Besucher triggern und Buchungsstatus-Ereignisse in der Chat-Timeline sehen.
Wenn Booking Assistant nicht installiert ist, funktionieren Chat und Support-Posteingang weiterhin normal.

= Warum wird das Overlay nicht angezeigt, obwohl es aktiviert ist? =

Hauefig ist eine der folgenden Bedingungen nicht erfuellt:

* Das Overlay ist aktiviert, aber es ist keine Kanal-URL hinterlegt und der integrierte Website-Chat ist deaktiviert.
* "Require cookie consent" ist aktiviert, aber die konfigurierten Cookie-Regeln passen nicht zu den tatsaechlichen Consent-Cookies der Seite.

Wenn deine Seite ein eigenes Theme oder Consent-Setup verwendet, aktualisiere "Consent cookie rules" entsprechend.

= Gibt es eine deutsche Setup-Anleitung und ein Support-Playbook? =

Ja. Siehe folgende Dateien im Plugin-Ordner:

* README.de.md
* SUPPORT-PLAYBOOK.md
* RELEASE-CHECKLIST.md

== Privacy ==

Wenn Website-Chat aktiviert ist, werden Besuchernachrichten in WordPress-Optionen gespeichert, um den Unterhaltungsverlauf zu behalten.
Wenn Support-E-Mail-Benachrichtigungen aktiviert sind, wird der Nachrichteninhalt per E-Mail an die konfigurierte Support-Adresse gesendet.
Wenn KI-Autoantwort aktiviert ist, wird der Nachrichteninhalt an den konfigurierten KI-API-Endpunkt gesendet.

Die Datenschutzerklaerung sollte entsprechend angepasst werden.

== Screenshots ==

1. Schwebender Chat-Button und Kanal-Panel im Frontend.
2. Nativer Website-Chat im Overlay.
3. Support-Posteingang im eigenen WordPress-Admin-Menue Support Chat.
4. E-Mail-Benachrichtigung mit direktem Unterhaltungs-Link.
5. KI-Konfigurationseinstellungen.

== Changelog ==

= 1.4.0 =
* Support-Posteingangs-Aktion "Open Booking Overlay at Client" hinzugefuegt, wenn Booking Assistant verfuegbar ist.
* Buchungsereignis-Nachrichten fuer Besucher-bestaetigte und Besucher-abgebrochene Buchungsablaeufe hinzugefuegt.
* Visuelle Badges und Schnellfilter fuer Buchungs-/Systemereignisse im Support-Posteingang hinzugefuegt.
* Einmalige Behandlung des Booking-Triggers im Frontend hinzugefuegt, um wiederholte Auto-Open-Schleifen zu vermeiden.
* Kompatibilitaets-Guard hinzugefuegt, damit die Booking-Aktion ausgeblendet wird, wenn Booking Assistant nicht aktiv ist.

= 1.3.0 =
* Admin-Settings-UX mit klarerer Grundfuehrung und aufklappbaren Expertensektionen verbessert.
* Verbindliches Verhalten fuer Support-E-Mail-Feld in integrierten Chat-Workflows hinzugefuegt.
* Validierungs-Fallback hinzugefuegt: integrierter Chat faellt bei leerer Support-E-Mail automatisch auf Admin-E-Mail zurueck.
* Validierungs-Fallback hinzugefuegt: KI-Autoantwort wird bei fehlendem API-Key automatisch deaktiviert.
* Legacy-Dead-Code fuer deprecated Chat-Reset-Hour-Option entfernt.

= 1.2.1 =
* Reproduzierbaren Release-ZIP-Packaging-Workflow hinzugefuegt.
* Installationshinweise fuer externe WordPress-Umgebungen hinzugefuegt.

= 1.2.0 =
* Nativen Website-Chat im Overlay hinzugefuegt.
* Support-Posteingang in den Admin-Einstellungen hinzugefuegt.
* Support-E-Mail-Benachrichtigungen mit direktem Unterhaltungs-Link hinzugefuegt.
* Optionale KI-Autoantwort-Konfiguration hinzugefuegt.
* Overlay-Rendering-Logik fuer Chat-Only-Modus verbessert.

= 1.1.0 =
* Multi-Channel-Floating-Overlay mit Auto-Open-Verzoegerung und Dismiss-Speicher hinzugefuegt.

== Upgrade Notice ==

= 1.4.0 =
Enthaelt optionale Booking-Assistant-Handover-Aktionen im Support-Posteingang und Verbesserungen der Sichtbarkeit von Buchungsereignissen.
Keine Aktion erforderlich, wenn Booking Assistant nicht installiert ist.

= 1.3.0 =
Enthaelt Verbesserungen der Admin-UX und strengere Validierungs-Defaults fuer Support-E-Mail- und KI-Einstellungen.

= 1.2.1 =
Enthaelt Packaging-Workflow fuer Releases und verbesserte Installationsanleitung.

= 1.2.0 =
Enthaelt integrierten Website-Chat, Support-Posteingang, E-Mail-Benachrichtigungen und optionale KI-Autoantwort.
Bitte Einstellungen nach dem Upgrade pruefen.

